plugins {
    id("java")
}

group = "org.example"
version = "1.0-SNAPSHOT"

repositories {
    mavenCentral()
}

dependencies {
    testImplementation(platform("org.junit:junit-bom:5.10.0"))
    testImplementation("org.junit.jupiter:junit-jupiter")
    testImplementation("org.junit.platform:junit-platform-suite:1.10.0") // ⬅️ ОЦЕ ДОДАЙ
    implementation("org.apache.commons:commons-math3:3.6.1")
    implementation(project(":utils"))
}

tasks.test {
    useJUnitPlatform()
}
