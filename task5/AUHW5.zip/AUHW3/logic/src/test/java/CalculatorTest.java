import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class CalculatorTest {

    private Calculator calculator;

    @BeforeEach
    void setUp() {
        calculator = new Calculator();
    }

    @Tag("add")
    @Test
    void testAddWithNormalNumbers() {
        String result = calculator.add(2.5, 3.25);
        assertEquals("The answer is: 5.75000000", result);
    }

    @Tag("add")
    @Test
    void testAddWithZero() {
        String result = calculator.add(0, 5.5);
        assertEquals("The answer is: 5.50000000", result);
    }

    @Tag("add")
    @Test
    void testAddWithNegativeNumbers() {
        String result = calculator.add(-2.5, -3.5);
        assertEquals("The answer is: -6.00000000", result);
    }

    @Tag("add")
    @Test
    void testAddWithMaxValue() {
        String result = calculator.add(Double.MAX_VALUE, 0);
        assertEquals(StringUtils.formatAnswer(Double.MAX_VALUE), result);
    }

    @Tag("subtract")
    @Test
    void testSubtractWithNormalNumbers() {
        String result = calculator.subtract(10, 3.5);
        assertEquals("The answer is: 6.50000000", result);
    }

    @Tag("subtract")
    @Test
    void testSubtractWithZero() {
        String result = calculator.subtract(7, 0);
        assertEquals("The answer is: 7.00000000", result);
    }

    @Tag("subtract")
    @Test
    void testSubtractWithNegativeNumbers() {
        String result = calculator.subtract(-5, -2);
        assertEquals("The answer is: -3.00000000", result);
    }

    @Tag("subtract")
    @Test
    void testSubtractWithMinValue() {
        String result = calculator.subtract(Double.MIN_VALUE, 0);
        assertEquals(StringUtils.formatAnswer(Double.MIN_VALUE), result);
    }

    @Tag("multiply")
    @Test
    void testMultiplyWithNormalNumbers() {
        String result = calculator.multiply(2.5, 4);
        assertEquals("The answer is: 10.00000000", result);
    }

    @Tag("multiply")
    @Test
    void testMultiplyWithZero() {
        String result = calculator.multiply(123.45, 0);
        assertEquals("The answer is: 0.00000000", result);
    }

    @Tag("multiply")
    @Test
    void testMultiplyWithNegativeNumbers() {
        String result = calculator.multiply(-3, 2);
        assertEquals("The answer is: -6.00000000", result);
    }

    @Tag("multiply")
    @Test
    void testMultiplyWithMaxValue() {
        String result = calculator.multiply(Double.MAX_VALUE, 1);
        assertEquals(StringUtils.formatAnswer(Double.MAX_VALUE), result);
    }

    @Tag("divide")
    @Test
    void testDivideWithNormalNumbers() {
        String result = calculator.divide(10, 2);
        assertEquals("The answer is: 5.00000000", result);
    }

    @Tag("divide")
    @Test
    void testDivideWithZeroNumerator() {
        String result = calculator.divide(0, 3.14);
        assertEquals("The answer is: 0.00000000", result);
    }

    @Tag("divide")
    @Test
    void testDivideWithNegativeNumbers() {
        String result = calculator.divide(-9, 3);
        assertEquals("The answer is: -3.00000000", result);
    }

    @Tag("divide")
    @Test
    void testDivideByZeroThrowsException() {
        assertThrows(ArithmeticException.class, () -> calculator.divide(10, 0));
    }
}
