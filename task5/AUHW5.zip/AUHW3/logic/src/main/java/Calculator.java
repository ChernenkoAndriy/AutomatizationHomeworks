

import org.apache.commons.math3.util.Precision;

public class Calculator {

    public String add(double a, double b) {
        double result = Precision.round(a + b, 8);
        return StringUtils.formatAnswer(result);
    }

    public String subtract(double a, double b) {
        double result = Precision.round(a - b, 8);
        return StringUtils.formatAnswer(result);
    }

    public String multiply(double a, double b) {
        double result = Precision.round(a * b, 8);
        return StringUtils.formatAnswer(result);
    }

    public String divide(double a, double b) {
        if (b == 0) throw new ArithmeticException("Division by zero");
        double result = Precision.round(a / b, 8);
        return StringUtils.formatAnswer(result);
    }
}
