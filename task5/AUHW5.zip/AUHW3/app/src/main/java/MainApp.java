import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

public class MainApp extends Application {

    private final Calculator calculator = new Calculator();

    @Override
    public void start(Stage stage) {
        TextField input1 = new TextField();
        input1.setPromptText("Enter first number");

        TextField input2 = new TextField();
        input2.setPromptText("Enter second number");

        ComboBox<String> operations = new ComboBox<>();
        operations.getItems().addAll("+", "-", "*", "/");
        operations.setValue("+");

        Button calcButton = new Button("Calculate");
        Label resultLabel = new Label();

        calcButton.setOnAction(e -> {
            try {
                double a = Double.parseDouble(input1.getText());
                double b = Double.parseDouble(input2.getText());
                String op = operations.getValue();

                String output = switch (op) {
                    case "+" -> calculator.add(a, b);
                    case "-" -> calculator.subtract(a, b);
                    case "*" -> calculator.multiply(a, b);
                    case "/" -> calculator.divide(a, b);
                    default -> "Unknown operation";
                };

                resultLabel.setText(output);
            } catch (NumberFormatException ex) {
                resultLabel.setText("Invalid number format!");
            } catch (ArithmeticException ex) {
                resultLabel.setText("Error: " + ex.getMessage());
            }
        });

        VBox root = new VBox(10, input1, input2, operations, calcButton, resultLabel);
        root.setPadding(new Insets(15));

        Scene scene = new Scene(root, 300, 220);
        stage.setTitle("Simple Calculator");
        stage.setScene(scene);
        stage.show();
    }

    public static void main(String[] args) {
        launch();
    }
}
