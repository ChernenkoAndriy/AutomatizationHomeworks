import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.Assumptions;
import org.testfx.framework.junit5.ApplicationTest;

import static org.junit.jupiter.api.Assertions.assertEquals;

public class MainAppTest extends ApplicationTest {

    @Override
    public void start(Stage stage) throws Exception {
        new MainApp().start(stage);
    }

    @BeforeEach
    void setUpEach() {
    }

    @Test
    void testAddition() {
        ComboBox<String> combo = lookup(".combo-box").query();
        Assumptions.assumeTrue(combo.getItems().contains("+"), "Operation '+' is not available");

        clickOn(".text-field").write("5");
        type(javafx.scene.input.KeyCode.TAB);
        write("3");
        clickOn("Calculate");

        Label resultLabel = lookup(".label").queryAllAs(Label.class).stream()
                .filter(label -> label.getText().startsWith("The answer"))
                .findFirst().orElseThrow();

        assertEquals("The answer is: 8.00000000", resultLabel.getText());
    }

    @Test
    void testInvalidInput() {
        TextField firstField = lookup(".text-field").query();
        Assumptions.assumeTrue(firstField.getText().isEmpty(), "Text field is not empty");

        clickOn(".text-field").write("abc");
        type(javafx.scene.input.KeyCode.TAB);
        write("3");
        clickOn("Calculate");

        Label resultLabel = lookup(".label").queryAllAs(Label.class).stream()
                .filter(label -> label.getText().contains("Invalid"))
                .findFirst().orElseThrow();

        assertEquals("Invalid number format!", resultLabel.getText());
    }

    @Test
    void testDivisionByZero() {
        ComboBox<String> combo = lookup(".combo-box").query();
        Assumptions.assumeTrue(combo.getItems().contains("/"), "Division not supported");

        clickOn(".text-field").write("5");
        type(javafx.scene.input.KeyCode.TAB);
        write("0");

        interact(() -> combo.setValue("/"));
        clickOn("Calculate");

        Label resultLabel = lookup(".label").queryAllAs(Label.class).stream()
                .filter(label -> label.getText().startsWith("Error"))
                .findFirst().orElseThrow();

        assertEquals("Error: Division by zero", resultLabel.getText());
    }
}
