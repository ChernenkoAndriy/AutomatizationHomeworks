plugins {
    id("java")
    id("org.openjfx.javafxplugin") version "0.0.13"
}

group = "org.example"
version = "1.0-SNAPSHOT"


repositories {
    mavenCentral()
    maven { url = uri("https://oss.sonatype.org/content/repositories/snapshots") }
}


dependencies {
    // JUnit 5
    testImplementation(platform("org.junit:junit-bom:5.10.0"))
    testImplementation("org.junit.jupiter:junit-jupiter")

    // TestFX для JavaFX GUI-тестів
    testImplementation("org.testfx:testfx-junit5:4.0.16-alpha")
    testImplementation("org.testfx:openjfx-monocle:8u76-b04")

    // Власний модуль логіки
    implementation(project(":logic"))
}

tasks.test {
    useJUnitPlatform()
    // За потреби:
    // systemProperty("java.awt.headless", "true")
}

javafx {
    version = "21"
    modules = listOf("javafx.controls", "javafx.fxml")
}
