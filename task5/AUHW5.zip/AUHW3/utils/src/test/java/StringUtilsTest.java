import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;

public class StringUtilsTest {

    @Test
    void testFormatAnswer() {
        double input = 3.1415926535;
        String expected = "The answer is: 3.14159265";
        String actual = StringUtils.formatAnswer(input);
        assertEquals(expected, actual);
    }

    @Test
    void testFormatAnswerWithZero() {
        double input = 0.0;
        String expected = "The answer is: 0.00000000";
        String actual = StringUtils.formatAnswer(input);
        assertEquals(expected, actual);
    }

    @Test
    void testFormatAnswerWithMaxDouble() {
        double input = Double.MAX_VALUE;
        String expected = String.format("The answer is: %.8f", input);
        String actual = StringUtils.formatAnswer(input);
        assertEquals(expected, actual);
    }
}
