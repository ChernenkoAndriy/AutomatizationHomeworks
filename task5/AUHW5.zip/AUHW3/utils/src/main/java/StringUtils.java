
public class StringUtils {
    public static String formatAnswer(double value) {
        return String.format("The answer is: %.8f", value);
    }
}
