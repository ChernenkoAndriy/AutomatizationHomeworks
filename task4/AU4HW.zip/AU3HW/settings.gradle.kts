rootProject.name = "AU3HW"
include("app")
include("logic")
include("utils")
pluginManagement {
    repositories {
        mavenLocal()
        gradlePluginPortal()
        mavenCentral()
    }
}
