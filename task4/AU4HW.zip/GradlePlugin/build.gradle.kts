plugins {
    `java-gradle-plugin`
    `maven-publish`
}

group = "org.example"
version = "1.0.0"

java {
    sourceCompatibility = JavaVersion.VERSION_11
    targetCompatibility = JavaVersion.VERSION_11
}

gradlePlugin {
    plugins {
        create("fileCounterPlugin") {
            id = "org.example.file-counter"
            implementationClass = "org.example.FileCounterPlugin"
            displayName = "File Counter Plugin"
            description = "A plugin for counting files in directories"
        }
    }
}

repositories {
    gradlePluginPortal()
    mavenCentral()
}

dependencies {
    testImplementation("org.junit.jupiter:junit-jupiter:5.9.2")
    testRuntimeOnly("org.junit.platform:junit-platform-launcher")
}

tasks.test {
    useJUnitPlatform()
}

publishing {
    repositories {
        maven {
            name = "local"
            url = uri("file://${rootProject.projectDir}/local-repo")
        }
    }
}