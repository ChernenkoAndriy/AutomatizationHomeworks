package org.example;

import org.gradle.api.Plugin;
import org.gradle.api.Project;

public class FileCounterPlugin implements Plugin<Project> {
    @Override
    public void apply(Project project) {
        // Реєструємо основну таску для підрахунку файлів
        project.getTasks().register("countFiles", FileCounterTask.class, task -> {
            task.setDescription("Counts files recursively in the specified folder");
            task.setGroup("file-operations");
        });

        // Додаємо нову таску для підрахунку файлів за розширенням
        project.getTasks().register("countFilesByExtension", FileCounterByExtensionTask.class, task -> {
            task.setDescription("Counts files by extension recursively in the specified folder");
            task.setGroup("file-operations");
        });
    }
}