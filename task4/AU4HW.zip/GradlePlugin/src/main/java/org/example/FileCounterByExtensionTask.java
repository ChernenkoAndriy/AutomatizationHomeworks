package org.example;

import org.gradle.api.DefaultTask;
import org.gradle.api.GradleException;
import org.gradle.api.tasks.Input;
import org.gradle.api.tasks.Optional;
import org.gradle.api.tasks.TaskAction;
import org.gradle.api.tasks.options.Option;

import java.io.File;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Map;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class FileCounterByExtensionTask extends DefaultTask {

    private File folder;
    private Boolean showTotal = true; // Змінено на обгортку Boolean

    public FileCounterByExtensionTask() {
        this.folder = getProject().getProjectDir();
    }

    @Input
    @Optional
    public String getFolderPath() {
        return folder.getAbsolutePath();
    }

    @Option(option = "folder", description = "Folder to count files in")
    public void setFolder(String folderPath) {
        this.folder = new File(folderPath);
    }

    public void setFolder(File folder) {
        this.folder = folder;
    }

    @Input
    @Optional
    public Boolean getShowTotal() {
        return showTotal;
    }

    @Option(option = "show-total", description = "Show total count")
    public void setShowTotal(boolean showTotal) {
        this.showTotal = showTotal;
    }

    @TaskAction
    public void countFilesByExtension() {
        if (!folder.exists() || !folder.isDirectory()) {
            throw new GradleException("Invalid folder: " + folder.getAbsolutePath());
        }

        try (Stream<Path> stream = Files.walk(folder.toPath())) {
            Map<String, Long> extensionCounts = stream
                    .filter(Files::isRegularFile)
                    .collect(Collectors.groupingBy(
                            this::getFileExtension,
                            Collectors.counting()
                    ));

            getLogger().lifecycle("File count by extension in: {}", folder.getAbsolutePath());
            getLogger().lifecycle("==========================================");

            long totalFiles = 0;
            for (Map.Entry<String, Long> entry : extensionCounts.entrySet()) {
                String extension = entry.getKey();
                Long count = entry.getValue();
                totalFiles += count;

                if (extension.isEmpty()) {
                    getLogger().lifecycle("Files without extension: {}", count);
                } else {
                    getLogger().lifecycle(".{} files: {}", extension, count);
                }
            }

            if (Boolean.TRUE.equals(showTotal)) {
                getLogger().lifecycle("==========================================");
                getLogger().lifecycle("Total files: {}", totalFiles);
            }

        } catch (Exception e) {
            throw new GradleException("Error counting files by extension", e);
        }
    }

    private String getFileExtension(Path path) {
        String fileName = path.getFileName().toString();
        int lastDotIndex = fileName.lastIndexOf('.');

        if (lastDotIndex > 0 && lastDotIndex < fileName.length() - 1) {
            return fileName.substring(lastDotIndex + 1).toLowerCase();
        }

        return ""; // файли без розширення
    }
}
