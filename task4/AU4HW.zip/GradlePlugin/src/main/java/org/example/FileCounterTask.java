package org.example;

import org.gradle.api.DefaultTask;
import org.gradle.api.GradleException;
import org.gradle.api.tasks.InputDirectory;
import org.gradle.api.tasks.Optional;
import org.gradle.api.tasks.TaskAction;
import org.gradle.api.tasks.options.Option;

import java.io.File;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.stream.Stream;

public class FileCounterTask extends DefaultTask {

    private File folder;

    public FileCounterTask() {
        // Значення за замовчуванням — директорія проєкту
        this.folder = getProject().getProjectDir();
    }

    @InputDirectory
    @Optional
    public File getFolder() {
        return folder;
    }

    @Option(option = "folder", description = "Folder to count files in")
    public void setFolder(String folderPath) {
        this.folder = new File(folderPath);
    }

    public void setFolder(File folder) {
        this.folder = folder;
    }

    @TaskAction
    public void countFiles() {
        if (!folder.exists() || !folder.isDirectory()) {
            throw new GradleException("Invalid folder: " + folder.getAbsolutePath());
        }

        try (Stream<Path> stream = Files.walk(folder.toPath())) {
            long count = stream
                    .filter(Files::isRegularFile)
                    .count();

            getLogger().lifecycle("Found " + count + " files recursively in: " + folder.getAbsolutePath());

        } catch (Exception e) {
            throw new GradleException("Error counting files", e);
        }
    }
}
