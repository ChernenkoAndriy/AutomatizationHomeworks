package logic;

import org.apache.commons.math3.util.Precision;
import utils.StringUtils;

public class Calculator {

    public double add(double a, double b) {
        return Precision.round(a + b, 8);
    }

    public double subtract(double a, double b) {
        return Precision.round(a - b, 8);
    }

    public double multiply(double a, double b) {
        return Precision.round(a * b, 8);
    }

    public double divide(double a, double b) {
        if (b == 0) throw new ArithmeticException("Division by zero");
        return Precision.round(a / b, 8);
    }

    public String addWithTimestamp(double a, double b) {
        double result = add(a, b);
        return StringUtils.formatResultWithTimestamp(result);
    }
}
