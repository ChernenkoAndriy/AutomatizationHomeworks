package org.example;

import org.apache.maven.plugin.AbstractMojo;
import org.apache.maven.plugin.MojoExecutionException;
import org.apache.maven.plugins.annotations.Mojo;
import org.apache.maven.plugins.annotations.Parameter;

import java.io.File;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.stream.Stream;

@Mojo(name = "count-files")
public class FileCounterMojo extends AbstractMojo {

    @Parameter(property = "folder", defaultValue = "${project.basedir}")
    private File folder;

    @Override
    public void execute() throws MojoExecutionException {
        if (!folder.exists() || !folder.isDirectory()) {
            throw new MojoExecutionException("Invalid folder: " + folder.getAbsolutePath());
        }

        try (Stream<Path> stream = Files.walk(folder.toPath())) {
            long count = stream
                    .filter(Files::isRegularFile)
                    .count();

            getLog().info("Found " + count + " files recursively in: " + folder.getAbsolutePath());

        } catch (Exception e) {
            throw new MojoExecutionException("Error counting files", e);
        }
    }
}
